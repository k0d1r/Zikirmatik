//
//  veriablesWiew.swift
//  ZikirMatik
//
//  Created by ALP on 14.09.2023.
//

import Foundation
import UIKit

struct ColorRandomList{
    
    let colorlist = [
        UIColor.black,
        UIColor.red,
        UIColor.yellow,
        UIColor.lightGray,
        UIColor.gray,
    ]
}
