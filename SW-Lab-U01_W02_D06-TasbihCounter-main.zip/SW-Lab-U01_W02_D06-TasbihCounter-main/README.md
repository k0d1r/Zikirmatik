# SW-Lab-U01_W02_D06-TasbihCounter
Second App consisting of a Tasbih counter.

## Topics
1. Storyboard
2. UIKit
3. SF Symbols
4. Inheritance
4. Constraints
5. Design pattern: Publish-Subscriber
6. Connect properties from Storyboad to code with @IBOutlet .
7. Connect methods from Storyboad to code with @IBAction

## Description
1. Create TasbihCounter App. 

## Deadline 
Monday 11th October 9:15 am
![Simulator Screen Shot - iPhone 12 - 2021-10-11 at 12 00 34](https://user-images.githubusercontent.com/91871608/136806508-902313d0-6f87-4435-ba6f-e5d93e63359d.png)
