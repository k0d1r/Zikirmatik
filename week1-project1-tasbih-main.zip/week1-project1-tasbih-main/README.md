# Week 1: Tasbih App

## Project Overview
- Displays the count tasbih
- Button to increase it
- Button to reset it

![CleanShot 2021-09-25 at 11 49 59](https://user-images.githubusercontent.com/34512743/134765673-75d7eb2c-d018-493f-a449-26aa9d2bdad8.png)


## What will you learn?
- Create a user interface
- Link button actions to user interface changes

## Why is this project meaningful to my career?
The project will make you practice for our next apps that we are gonna build later.

## Due date
Thursday 30 September
