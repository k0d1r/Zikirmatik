//
//  TesbihApp.swift
//  Tesbih
//
//  Created by MacBook Pro on 10/27/22.
//

import SwiftUI

@main
struct TesbihApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
