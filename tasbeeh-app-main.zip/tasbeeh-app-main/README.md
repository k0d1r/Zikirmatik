# Tasbih iOS App

## _This is tasbih app with simple feature: counting tasbihs you wish to dhikr._



## Features
- Display about app
- Count & Save tasbih while app is open.
- Select dhikr you want to make.


## Feel free to contribute ❤️
